function postular{
alert("Su Registro Se Ha Completado");
}